---
name: ui-library-selector
description: Select, search, and install the right React UI component libraries for UI pages, layout redesigns, interaction polish, prototypes, landing pages, SaaS/product apps, dashboards, admin panels, portfolios, data-heavy pages, or custom design systems. Use when an AI coding agent is asked to build or modify UI, beautify UI, polish a page, make a page look better, improve a bad-looking page, optimize the current interface, improve layout, redesign a screen, create a UI prototype, improve visual quality, add interactions/animations, choose component libraries, install UI components, compare shadcn/ui, React Bits, Magic UI, Aceternity UI, MUI, Ant Design, Mantine, Chakra UI, HeroUI, Radix UI, React Aria, Headless UI, PrimeReact, or Fluent UI, or reduce token/time cost when finding UI components. Also use for colloquial Chinese requests such as UI美化, 美化UI, 美化界面, 页面不好看, 页面效果不好, 改页面, 改布局, 优化界面, 优化当前页面, 做UI页面, 做原型, 提升页面质感, or 交互效果更好.
---

# UI Library Selector

## Role With Design Skills

This skill solves the "available materials" problem for UI work. Design/frontend skills improve art direction, visual hierarchy, typography, motion, and critique, but they usually do not maintain a current component-object pool or install strategy. Use this skill first when a UI task needs better components, richer interactions, or production-ready building blocks.

Pair this skill with any available design/frontend skill:

1. Use this skill to classify the UI type and choose the component source.
2. Search only the relevant component categories instead of crawling whole websites.
3. Install or introduce the selected components with the correct CLI/npm mechanism.
4. Use the design/frontend skill to shape the final composition, brand direction, spacing, typography, motion, and self-critique.

When both skills apply, do not treat them as alternatives. This skill provides high-quality UI materials; the design/frontend skill turns those materials into a coherent product experience.

Trigger this skill even when the user phrases the request casually, such as "beautify this UI", "make the page look better", "fix the layout", "polish the current interface", "页面不好看", "美化界面", "改布局", or "提升页面质感". Treat those as UI material-selection tasks when better components, page sections, interaction patterns, or visual effect components may improve the result.

## Workflow

1. Inspect the project before recommending a new UI system:
   - `package.json`
   - lockfiles
   - `components.json`
   - existing `components/ui`, `src/components`, `app/components`
   - Tailwind/global CSS/theme files
2. If the UI type is unclear, ask up to 5 concise questions:
   - What are we building: landing page, product app, admin dashboard, portfolio, data-heavy view, internal tool, or design system?
   - What matters most: visual impact, production stability, speed, accessibility, complex forms/data, or brand customization?
   - What stack and styling system already exist?
   - Should it follow an existing design language or look custom/branded?
   - Are animations allowed, and are there mobile/performance constraints?
3. Classify the UI type.
4. Evaluate the existing implementation and component set:
   - Can existing components satisfy the request?
   - Would a different component/library make the result materially better?
   - Is the quality gain worth the added dependency, style-system complexity, and maintenance cost?
5. If a design/frontend skill or project design rules are available, use them after library selection to refine visual direction and quality checks.
6. Choose one primary UI library and, at most, one visual/effect library.
7. Read only the relevant reference file:
   - `references/decision-matrix.md` for choosing libraries.
   - `references/component-search-index.md` for category-limited searching.
   - `references/install-commands.md` for CLI/npm commands.
   - `references/library-catalog.md` for library strengths and tradeoffs.
8. Search only the relevant component categories. Never crawl a whole component-library website by default.
9. Install with the correct mechanism:
   - copy-to-code registry components: use `shadcn` CLI.
   - npm component libraries: install package dependencies.
10. Verify by running the project’s normal typecheck/build/lint command when available.

## Library Selection Rules

- Prefer the project’s existing UI system when it can meet the quality bar.
- Recommend a new component/library when it gives a material improvement in interaction quality, accessibility, responsive behavior, visual polish, maintainability, performance, or implementation speed.
- Do not block a better solution just because an existing component can technically be made to work.
- Do not add a new library for a small cosmetic gain that can be achieved cleanly with existing components.
- Use **shadcn/ui** for modern general UI and AI-editable local components.
- Use **Ant Design**, **MUI**, or **PrimeReact** for admin, enterprise, CRUD, table-heavy, or data-heavy apps.
- Use **Mantine** for product apps that need broad coverage and good developer experience without a strong Material/Ant visual signature.
- Use **HeroUI** or **Chakra UI** for fast modern npm-based product UI.
- Use **Radix UI** or **React Aria Components** for custom design systems and accessibility-critical custom components.
- Use **React Bits**, **Magic UI**, or **Aceternity UI** for visual polish, landing pages, hero sections, animated backgrounds, and memorable interactions.
- Use **Fluent UI** for Microsoft-style enterprise/internal tools.

Do not combine multiple primary UI systems in the same feature unless the repo already does so. Do not combine multiple visual effect libraries on one page unless the user explicitly asks.

## Default Recommendations

- Landing page: `shadcn/ui` + one of `Magic UI`, `Aceternity UI`, or `React Bits`.
- Portfolio/showcase: `shadcn/ui` + `React Bits` or `Aceternity UI`.
- SaaS/product app: `shadcn/ui` or `Mantine`.
- Admin/internal tool: `Ant Design`, `MUI`, or `Mantine`.
- Data-heavy view: `Ant Design`, `MUI X`, or `PrimeReact`.
- Custom design system: `Radix UI` or `React Aria Components`.
- Microsoft ecosystem: `Fluent UI`.

## Search Discipline

Before browsing or installing, map the UI need to a small component set:

- forms: input, select, checkbox, radio, switch, textarea, form validation
- overlays: dialog, drawer, popover, tooltip, alert dialog
- navigation: tabs, sidebar, menu, breadcrumbs, pagination
- data display: table, card, badge, avatar, list, chart
- feedback: toast, alert, progress, skeleton, spinner
- marketing: hero, bento, marquee, testimonials, pricing, CTA
- visual effects: animated background, text animation, hover effect, cursor effect, 3D card

Load `references/component-search-index.md` and search only the matching section.

## Better-Than-Existing Test

Before installing anything, compare the existing approach with the candidate component/library:

- **Interaction quality**: keyboard behavior, focus management, gestures, transitions, loading/empty/error states.
- **Accessibility**: ARIA, screen-reader behavior, contrast, reduced motion, focus rings.
- **Responsive quality**: mobile layout, touch targets, overflow, density, breakpoints.
- **Visual quality**: hierarchy, spacing, motion taste, brand fit, consistency with current design.
- **Maintainability**: local source editability, API simplicity, dependency health, team familiarity.
- **Performance**: bundle impact, WebGL/animation cost, virtualization for large data.
- **Speed**: whether a proven component avoids fragile hand-rolled code.

Install or introduce a new library only when at least one quality gain is meaningful for the current UI type.

## Install Discipline

Detect package manager from lockfiles:

- `pnpm-lock.yaml` -> `pnpm`
- `yarn.lock` -> `yarn`
- `bun.lock` or `bun.lockb` -> `bun`
- `package-lock.json` -> `npm`
- otherwise default to `npm`

Use `references/install-commands.md` to generate exact commands.

If network access is blocked, request approval for the specific install command.

## Response Format

When recommending or installing UI libraries, report:

1. UI type classification.
2. Primary UI library.
3. Optional visual/effect library.
4. Exact components/categories to inspect.
5. Exact install commands.
6. Why these choices fit.
7. What not to use and why.
8. Verification performed or still needed.
