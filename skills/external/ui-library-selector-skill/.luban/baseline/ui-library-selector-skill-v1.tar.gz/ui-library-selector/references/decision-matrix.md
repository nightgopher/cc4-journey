# Decision Matrix

## Primary UI Library

| UI Type | First Choice | Alternatives | Avoid |
|---|---|---|---|
| Modern app or prototype | shadcn/ui | Mantine, HeroUI | Mixing MUI + Ant + shadcn |
| SaaS/product app | shadcn/ui or Mantine | Chakra UI, HeroUI | Heavy animation libraries for core flows |
| Admin dashboard | Ant Design | MUI, Mantine, PrimeReact | React Bits/Magic UI as primary UI |
| Data-heavy page | MUI X, Ant Design, PrimeReact | Mantine | Hand-rolled data grid |
| Portfolio/showcase | shadcn/ui + React Bits | Aceternity UI, Magic UI | Ant Design/MUI as visual base |
| Landing/marketing page | shadcn/ui + Magic UI | Aceternity UI, React Bits | Enterprise UI libraries as primary visual style |
| Custom design system | Radix UI or React Aria Components | Headless UI | Styled monolith libraries if full control is required |
| Accessibility-critical custom UI | React Aria Components | Radix UI | Visual-only component snippets |
| Microsoft/internal enterprise | Fluent UI | MUI, Ant Design | Highly branded animation libraries |

## Effect Library Choice

Pick only one effect library by default:

- **React Bits**: best for advanced animated backgrounds, shader/WebGL visuals, text animations, interactive cards, profile/showcase effects.
- **Magic UI**: best for landing page building blocks, device mockups, bento, marquee, text reveal, border beam, terminal/code visuals.
- **Aceternity UI**: best for high-impact hero sections, strong animated marketing patterns, 3D cards, sticky scroll, beams, testimonials.

Use no effect library for admin, CRUD, settings, data entry, or dense operational screens unless there is a very specific interaction need.

## Quality Bias

- If the UI must be stable and accessible: prefer production npm libraries.
- If the UI must be highly custom and AI-editable: prefer shadcn/copy-to-code.
- If the UI must feel memorable: add one visual/effect library.
- If the UI is a workflow tool used repeatedly: keep animation restrained.

## Existing vs Better Component Decision

Do not ask only "can the current component solve it?" Ask "can the current component solve it at the desired quality level?"

Keep the current components when:

- the requested change is mostly layout, spacing, copy, color, or responsive adjustment;
- the project already has a coherent component system;
- a new library would duplicate existing primitives;
- the quality gain is minor.

Introduce a better component/library when:

- the existing implementation lacks robust keyboard/focus/accessibility behavior;
- the UI needs complex behavior such as date range picking, virtualized table, drag/drop, command palette, carousel gestures, or advanced filtering;
- the desired visual effect is a key part of the experience and would be fragile to hand-roll;
- the candidate component is more maintainable than custom code;
- the project type rewards the improvement, for example a landing page hero, portfolio showcase, or data-heavy dashboard.

When uncertain, recommend both options:

1. Use existing components for minimal dependency cost.
2. Add a candidate library/component for higher quality.

Then ask the user which tradeoff they prefer before installing.
