# Component Search Index

Use this file to avoid full-site crawling. Search only the category that matches the current UI task.

## shadcn/ui

Use for foundational app UI. Install via `npx shadcn@latest add ...`.

- Actions: `button`, `button-group`, `toggle`, `toggle-group`
- Forms: `form`, `input`, `input-group`, `textarea`, `select`, `native-select`, `checkbox`, `radio-group`, `switch`, `slider`, `calendar`, `input-otp`, `field`, `label`
- Overlays: `dialog`, `alert-dialog`, `drawer`, `sheet`, `popover`, `hover-card`, `tooltip`, `context-menu`, `dropdown-menu`
- Navigation: `tabs`, `navigation-menu`, `menubar`, `breadcrumb`, `pagination`, `sidebar`
- Data display: `table`, `card`, `badge`, `avatar`, `accordion`, `chart`, `item`, `empty`, `scroll-area`, `resizable`
- Feedback: `alert`, `progress`, `skeleton`, `sonner`, `spinner`

## React Bits

Use for visual/interactive polish. Install via `https://reactbits.dev/r/<Component>-<LANG>-<STYLE>`.

- Text animation: `SplitText`, `BlurText`, `GradientText`, `ShinyText`, `RotatingText`, `TextType`, `CountUp`, `ScrollReveal`, `DecryptedText`
- General animation: `AnimatedContent`, `FadeContent`, `GlareHover`, `ClickSpark`, `Magnet`, `Noise`, `StarBorder`, `PixelTransition`
- Components: `ProfileCard`, `TiltedCard`, `SpotlightCard`, `MagicBento`, `Dock`, `Carousel`, `Masonry`, `Stepper`, `ModelViewer`
- Backgrounds: `Aurora`, `Dither`, `Threads`, `Silk`, `Particles`, `DotGrid`, `Galaxy`, `LiquidEther`, `Iridescence`, `Waves`

## Magic UI

Use for landing pages and marketing sections. Install via `https://magicui.design/r/<component>.json`.

- Hero/marketing: `bento-grid`, `marquee`, `hero-video-dialog`, `terminal`, `tweet-card`, `code-comparison`
- Backgrounds: `animated-grid-pattern`, `grid-pattern`, `dot-pattern`, `retro-grid`, `particles`, `warp-background`
- Buttons/cards: `shimmer-button`, `rainbow-button`, `magic-card`, `neon-gradient-card`, `shine-border`
- Text: `animated-gradient-text`, `text-reveal`, `typing-animation`, `word-rotate`, `sparkles-text`
- Device/mockups: `iphone`, `android`, `safari`

## Aceternity UI

Use sparingly for strong visual moments. Install via `@aceternity/<component-name>`.

- Hero/background: `background-beams`, `background-gradient-animation`, `aurora-background`, `spotlight`, `vortex`, `shooting-stars`
- Cards: `3d-card`, `glare-card`, `wobble-card`, `card-spotlight`, `card-hover-effect`
- Marketing sections: `hero-parallax`, `sticky-scroll-reveal`, `bento-grid`, `animated-testimonials`, `timeline`
- Navigation: `floating-navbar`, `navbar-menu`, `resizable-navbar`, `sidebar`
- Text/effects: `typewriter-effect`, `text-generate-effect`, `flip-words`, `encrypted-text`, `colourful-text`

## MUI

Use package docs for exact imports.

- Core app UI: Button, TextField, Select, Checkbox, Radio, Switch, Dialog, Drawer, Menu, Tabs, Card
- Data: Table, List, Chip, Badge, Avatar
- Layout: Box, Container, Grid, Stack, Paper
- Feedback: Alert, Snackbar, Skeleton, Progress
- Advanced data: MUI X Data Grid, Date/Time Pickers

## Ant Design

- General: Button, Typography, Icon
- Layout/navigation: Layout, Menu, Breadcrumb, Pagination, Steps, Tabs
- Data entry: Form, Input, Select, DatePicker, TimePicker, Upload, Transfer, TreeSelect
- Data display: Table, Descriptions, List, Card, Calendar, Tree, Statistic, Timeline, Tag
- Feedback: Modal, Drawer, Message, Notification, Popconfirm, Progress, Skeleton, Spin, Result

## Mantine

- Layout: AppShell, Container, Grid, Group, Stack, Flex, SimpleGrid
- Inputs: TextInput, NumberInput, PasswordInput, Select, MultiSelect, TagsInput, Date inputs, FileInput
- Overlays: Modal, Drawer, Popover, HoverCard, Tooltip, Menu
- Feedback: Alert, Notification, Progress, Loader, Skeleton
- Display: Card, Badge, Avatar, Timeline, DataList, Table, Code, Typography

## Chakra UI

- Layout: Box, Flex, Grid, Stack, Container
- Forms: Field, Input, Select, Checkbox, Radio, Switch, Slider, TagsInput
- Overlays: Dialog, Drawer, Popover, Tooltip, Menu, HoverCard
- Feedback/display: Alert, Toast, Skeleton, Spinner, Progress, Card, Badge, Table, Timeline

## HeroUI

- Core: Button, ButtonGroup, Card, Modal, Drawer, Dropdown, Popover, Tooltip
- Forms: Input, TextArea, Select, Checkbox, RadioGroup, Switch, Slider, Form
- Advanced inputs: Calendar, DatePicker, DateRangePicker, ColorPicker, Autocomplete, ComboBox
- Data/display: Table, Pagination, Avatar, Badge, Chip, Toast, Tabs, TagGroup, Toolbar

## Radix UI

Use only for custom primitives:

- Dialog, AlertDialog, Popover, Tooltip, DropdownMenu, ContextMenu, Menubar
- Select, Checkbox, RadioGroup, Slider, Switch
- Tabs, Accordion, Collapsible, NavigationMenu, Toast

## React Aria Components

Use for accessibility-critical custom UI:

- Button, Dialog, Modal, Popover, Tooltip
- ComboBox, Select, ListBox, Menu, Tabs
- Calendar, DatePicker, DateRangePicker, TimeField
- Table, Tree, GridList, Virtualizer
- Drag and drop hooks, form controls

## PrimeReact

Use for data-heavy enterprise widgets:

- DataTable, TreeTable, VirtualScroller, Paginator
- FileUpload, Calendar, Dropdown, MultiSelect
- PickList, OrderList, OrganizationChart, Tree
- Chart, Galleria, Carousel, Timeline

## Fluent UI

Use for Microsoft-style internal tools:

- Button, Input, Combobox, Dropdown, Select
- Dialog, Drawer, Popover, Tooltip, Toast
- DataGrid, Table, Tree, List
- Persona, Avatar, Toolbar, Nav, Menu

