# Install Commands

## Package Manager Prefixes

Use project lockfiles:

| Lockfile | Package Manager | Install | DLX |
|---|---|---|---|
| `pnpm-lock.yaml` | pnpm | `pnpm add` | `pnpm dlx` |
| `yarn.lock` | yarn | `yarn add` | `yarn dlx` |
| `bun.lock` / `bun.lockb` | bun | `bun add` | `bunx --bun` |
| `package-lock.json` or none | npm | `npm install` | `npx` |

## Copy-To-Code Registries

### shadcn/ui

```bash
npx shadcn@latest add button dialog form table tabs
```

### React Bits

Pattern:

```bash
npx shadcn@latest add https://reactbits.dev/r/<Component>-<LANG>-<STYLE>
```

Variants:

- `JS-CSS`
- `JS-TW`
- `TS-CSS`
- `TS-TW`

Examples:

```bash
npx shadcn@latest add https://reactbits.dev/r/ProfileCard-TS-CSS
npx shadcn@latest add https://reactbits.dev/r/Aurora-TS-TW
```

### Magic UI

```bash
npx shadcn@latest add https://magicui.design/r/marquee.json
npx shadcn@latest add https://magicui.design/r/bento-grid.json
```

### Aceternity UI

```bash
npx shadcn@latest add @aceternity/background-beams
npx shadcn@latest add @aceternity/3d-card
```

## npm Libraries

### MUI

```bash
npm install @mui/material @emotion/react @emotion/styled
npm install @mui/x-data-grid
```

### Ant Design

```bash
npm install antd
```

### Mantine

```bash
npm install @mantine/core @mantine/hooks
```

### Chakra UI

```bash
npm install @chakra-ui/react
```

### HeroUI

```bash
npm install @heroui/react
```

### Radix UI

Install only primitives that are needed:

```bash
npm install @radix-ui/react-dialog
npm install @radix-ui/react-popover
npm install @radix-ui/react-select
```

### React Aria Components

```bash
npm install react-aria-components
```

### Headless UI

```bash
npm install @headlessui/react
```

### PrimeReact

```bash
npm install primereact primeicons
```

### Fluent UI

```bash
npm install @fluentui/react-components
```

### Icons

```bash
npm install lucide-react
```

## Approval Rule

If install commands fail because of network or sandbox restrictions, rerun the same command with escalation and ask for approval.

